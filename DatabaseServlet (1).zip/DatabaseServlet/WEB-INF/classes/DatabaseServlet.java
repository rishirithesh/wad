import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

// Displays all records of the Employees table on a GET request
public class DatabaseServlet extends HttpServlet {

    // Update these to match your MySQL setup
    private static final String URL  = "jdbc:mysql://localhost:3306/test";
    private static final String USER = "root";
    private static final String PASS = "your_password";

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>Employee Records</title></head><body>");
        out.println("<h2>Employee Records</h2>");
        out.println("<table border='1'><tr><th>ID</th><th>Age</th><th>First</th><th>Last</th></tr>");

        try {
            Class.forName("com.mysql.jdbc.Driver");           // load JDBC driver
            try (Connection con = DriverManager.getConnection(URL, USER, PASS);
                 Statement st = con.createStatement();
                 ResultSet rs = st.executeQuery("SELECT * FROM Employees")) {

                while (rs.next()) {
                    out.println("<tr><td>" + rs.getInt("id") + "</td><td>" + rs.getInt("age")
                            + "</td><td>" + rs.getString("first") + "</td><td>"
                            + rs.getString("last") + "</td></tr>");
                }
            }
        } catch (Exception e) {
            out.println("<tr><td colspan='4'>Error: " + e.getMessage() + "</td></tr>");
        }

        out.println("</table><br><a href='index.html'>Back</a></body></html>");
    }
}

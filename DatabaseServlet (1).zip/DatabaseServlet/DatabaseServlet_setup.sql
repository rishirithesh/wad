CREATE DATABASE IF NOT EXISTS test;

USE test;

CREATE TABLE IF NOT EXISTS Employees (
    id INT,
    age INT,
    first VARCHAR(20),
    last VARCHAR(20)
);

INSERT INTO Employees VALUES
(101, 20, 'Zara', 'Ali');

SELECT * FROM Employees;
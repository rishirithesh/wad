package com.example.backend;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class LombokTest {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    static class Hotel {
        private String id;
        private String name;
        private double rating;
    }

    @Test
    void testLombokGettersAndSetters() {
        Hotel hotel = new Hotel();
        hotel.setId("101");
        hotel.setName("Grand Palace");
        hotel.setRating(4.8);

        assertEquals("101", hotel.getId());
        assertEquals("Grand Palace", hotel.getName());
        assertEquals(4.8, hotel.getRating());
    }

    @Test
    void testLombokBuilder() {
        Hotel hotel = Hotel.builder()
                .id("102")
                .name("Ocean View Resort")
                .rating(4.9)
                .build();

        assertEquals("102", hotel.getId());
        assertEquals("Ocean View Resort", hotel.getName());
        assertEquals(4.9, hotel.getRating());
    }
}
